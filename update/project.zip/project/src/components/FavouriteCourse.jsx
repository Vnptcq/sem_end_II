const FavouriteCourse = () =>{
    return(
        <>
		
        </>
    )
}
export default FavouriteCourse;